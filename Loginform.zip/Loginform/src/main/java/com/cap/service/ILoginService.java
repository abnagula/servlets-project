package com.cap.service;

import com.cap.model.LoginBean;

public interface ILoginService {
	public boolean isValid(LoginBean loginBean);



}
