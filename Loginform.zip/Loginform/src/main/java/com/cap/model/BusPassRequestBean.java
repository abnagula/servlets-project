package com.cap.model;

import java.time.LocalDate;
import java.time.LocalTime;

public class BusPassRequestBean {
	
	

	
			private Integer requestid;
			private String employeeid;
			private String firstname;
			private String lastname;
			private String gender;
			private String address;
			private String emailid;
			private LocalDate doj;
			private String location;
			private String pickUpLoc;
			private LocalTime pickuptime;
			public BusPassRequestBean() {
				super();
			}
			public BusPassRequestBean(Integer requestid, String employeeid, String firstname, String lastname, String gender,
					String address, String emailid, LocalDate doj, String location, String pickUpLoc, LocalTime pickuptime) {
				super();
				this.requestid = requestid;
				this.employeeid = employeeid;
				this.firstname = firstname;
				this.lastname = lastname;
				this.gender = gender;
				this.address = address;
				this.emailid = emailid;
				this.doj = doj;
				this.location = location;
				this.pickUpLoc = pickUpLoc;
				this.pickuptime = pickuptime;
			}
			public Integer getRequestid() {
				return requestid;
			}
			public void setRequestid(Integer requestid) {
				this.requestid = requestid;
			}
			public String getEmployeeid() {
				return employeeid;
			}
			public void setEmployeeid(String employeeid) {
				this.employeeid = employeeid;
			}
			public String getFirstname() {
				return firstname;
			}
			public void setFirstname(String firstname) {
				this.firstname = firstname;
			}
			public String getLastname() {
				return lastname;
			}
			public void setLastname(String lastname) {
				this.lastname = lastname;
			}
			public String getGender() {
				return gender;
			}
			public void setGender(String gender) {
				this.gender = gender;
			}
			public String getAddress() {
				return address;
			}
			public void setAddress(String address) {
				this.address = address;
			}
			public String getEmailid() {
				return emailid;
			}
			public void setEmailid(String emailid) {
				this.emailid = emailid;
			}
			public LocalDate getDoj() {
				return doj;
			}
			public void setDoj(LocalDate doj) {
				this.doj = doj;
			}
			public String getLocation() {
				return location;
			}
			public void setLocation(String location) {
				this.location = location;
			}
			public String getPickUpLoc() {
				return pickUpLoc;
			}
			public void setPickUpLoc(String pickUpLoc) {
				this.pickUpLoc = pickUpLoc;
			}
			public LocalTime getPickuptime() {
				return pickuptime;
			}
			public void setPickuptime(LocalTime pickuptime) {
				this.pickuptime = pickuptime;
			}
			@Override
			public String toString() {
				return "PassRequestBean [requestid=" + requestid + ", employeeid=" + employeeid + ", firstname=" + firstname
						+ ", lastname=" + lastname + ", gender=" + gender + ", address=" + address + ", emailid=" + emailid
						+ ", doj=" + doj + ", location=" + location + ", pickUpLoc=" + pickUpLoc + ", pickuptime=" + pickuptime
						+ "]";
			}
			
			
		} 
		 



