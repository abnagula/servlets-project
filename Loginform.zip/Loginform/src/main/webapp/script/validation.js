function validation(){
	alert("hello");
	var flag=false;
	var userName=form1.userName.value;
	var userpasswd=form1.userPwd.value;
	if(userName==""||userName==null){
		document.getElementById('userErrorMsg').innerHTML="* Please enter user Name"
			flag=false;
	}else if(userpasswd==""||userpasswd==null){
		document.getElementById('pwdErrorMsg').innerHTML="* Please enter user Password"
			
			flag=false;
	}else{
		flag=true;
	}
	
	return flag;
}